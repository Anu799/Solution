package com.example.RestApi;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class ProductService {
    List<Product> products = new ArrayList<Product>();
    public List<Product> createProducts(){
        products.add(new Product("Prod1","Shirt","EACH") );
        products.add(new Product("Prod2","Trousers","EACH") );
        products.add(new Product("Prod3","Tie","EACH"));
        return products;
    }
    public Product checkStatus(Product products1){
        List<Product> ListOfProducts = createProducts();
        Product products2 = ListOfProducts.stream().filter(product -> product.getProductId().equals(products1.getProductId())).findAny().orElse(null);
        if(products2 != null)
            products2.setStatus("Exists");
        else {
            products1.setStatus("Created");
            ListOfProducts.add(products1);
            products2 = products1;
        }
        return products2;
    }

}

