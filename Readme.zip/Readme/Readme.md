com.example.RestApi---> Question 1

Open pom.xml in intellij

Execute RestApiApplication Class

