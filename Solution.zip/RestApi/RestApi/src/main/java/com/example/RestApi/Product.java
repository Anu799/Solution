package com.example.RestApi;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Product {
    private String productId;
    private String productName;
    private String unitOfMeasure;
    private String Status;

    public Product(String productId, String productName, String unitOfMeasure) {
        this.productId = productId;
        this.productName = productName;
        this.unitOfMeasure = unitOfMeasure;
    }

    public void setStatus(String status) {
        Status = status;
    }

    public String getProductId() {
        return productId;
    }

    public String getProductName() {
        return productName;
    }

    public String getUnitOfMeasure() {
        return unitOfMeasure;
    }

    public String getStatus() {
        return Status;
    }

    @Override
    public String toString() {
        return "Product{" +
                "productId='" + productId + '\'' +
                ", productName='" + productName + '\'' +
                ", unitOfMeasure='" + unitOfMeasure + '\'' +
                ", Status='" + Status + '\'' +
                '}';
    }
}
