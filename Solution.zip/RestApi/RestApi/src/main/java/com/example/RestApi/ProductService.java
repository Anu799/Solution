package com.example.RestApi;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class ProductService {
    List<Product> products = new ArrayList<Product>();
    public List<Product> createProducts(){
        products.add(new Product("Prod1","Shirt","EACH") );
        products.add(new Product("Prod2","Trousers","EACH") );
        products.add(new Product("Prod3","Tie","EACH"));
        return products;
    }
    public List<Product> checkStatus(Product products1){
        List<Product> ListOfProducts = createProducts();
        List<Product> products2 = ListOfProducts.stream().filter(product -> product.getProductId().equals(products1.getProductId())).collect(Collectors.toList());

        if(products2 != null) {
            products1.setStatus("Exists");
            products2.add(products1);
        }
        else {
            products1.setStatus("Created");
            products.add(products1);
            products2.add(products1);
        }

        return products2;
    }

}
